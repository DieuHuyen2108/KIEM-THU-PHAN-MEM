package Testcases;

import Common.Constant;
import PageObjects.*;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import PageObjects.BookTicketPage;
import PageObjects.ChangePasswordPage;
import PageObjects.MyTicketPage;
import PageObjects.RegisterPage;

import java.util.Random;

public class LoginTest {

    @BeforeMethod
    public void beforeMethod() {
        System.out.println("Pre-condition");

        Constant.WEBDRIVER =new ChromeDriver();
        Constant.WEBDRIVER.manage().window().maximize();
    }

    @AfterMethod
    public void afterMethod() {
        System.out.println("Post-condition");

        Constant.WEBDRIVER.quit();
    }


    @Test

    public void TC01() {
        System.out.println("TC01 - User can log into Railway with valid username and password");
        HomePage homePage = new HomePage();
        homePage.open();

        LoginPage loginPage = homePage.gotoLoginPage();

        String actualMsg = loginPage.login(Constant.USERNAME, Constant.PASSWORD).getWelcomeMessage();
        String expectedMsg = "Welcome " + Constant.USERNAME;

        Assert.assertEquals(actualMsg, expectedMsg, "Welcome message is not displayed as expected");

    }
    @Test
    public void TC02() {
        System.out.println("TC02 - User can't login with blank 'Username' textbox");

        HomePage homePage = new HomePage();
        homePage.open();

        LoginPage loginPage = homePage.gotoLoginPage();

        loginPage.getTxtPassword().sendKeys(Constant.PASSWORD);
        JavascriptExecutor js = (JavascriptExecutor) Constant.WEBDRIVER;
        js.executeScript("window.scrollBy(0,350)", "");

        loginPage.getBtnLogin().click();

        String expectedErrorMessage = "There was a problem with your login and/or errors exist in your form.";
        String actualErrorMessage = loginPage.getLblLoginErrorMsg().getText();

        Assert.assertEquals(actualErrorMessage, expectedErrorMessage, "Error message does not match!");
    }

    @Test
    public void TC03() {
        System.out.println("User cannot log into Railway with invalid password");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage LoginPage = homePage.gotoLoginPage();
        LoginPage.login(Constant.USERNAME, "invalid password" );
        JavascriptExecutor js = (JavascriptExecutor) Constant.WEBDRIVER;
        js.executeScript("window.scrollBy(0,350)", "");
        String actualErrorMsg = LoginPage.getLblLoginErrorMsg().getText();
        String expectedErrorMsg = "There was a problem with your login and/or errors exist in your form.";
        Assert.assertEquals(actualErrorMsg, expectedErrorMsg, "Error message is not displayed as expected");
    }

    @Test
    public void TC04() {
        System.out.println("Login page displays when un-logged User clicks on Book ticket");
        HomePage homePage = new HomePage();
        homePage.open();
        BookTicketPage bookPage = new BookTicketPage();
        bookPage = homePage.gotoBookTicketPage();
        String actualURL = bookPage.getCurrentPage();
        String expectedURL = Constant.RAILWAY_LOGIN_URL;
        Assert.assertEquals(actualURL, expectedURL, "Error message is not displayed as expected");
    }

    @Test
    public void TC05() {
        System.out.println("System shows message when user enters wrong password several times");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        for (int i = 0; i < 4; i++) {
            loginPage.login(Constant.USERNAME, "invalid password");
        }
        loginPage.login(Constant.USERNAME, "invalid password");
        String actualErrorMsg = loginPage.getLblLoginErrorMsg().getText();
        String expectedErrorMsg = "You have used 4 out of 5 login attempts. After all 5 have been used, you will be unable to login for 15 minutes.";
        Assert.assertEquals(actualErrorMsg, expectedErrorMsg, "Error message is not displayed as expected.");
    }

    @Test
    public void TC06() {
        System.out.println("Additional pages display once user logged in");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login(Constant.USERNAME, Constant.PASSWORD).getWelcomeMessage();
        MyTicketPage ticketPage = homePage.gotoMyTicketPage();
        Assert.assertNotNull(ticketPage,"user cannot directed to My ticket page");
        ChangePasswordPage changePasswordPage = ticketPage.gotoChangePasswordPage();
        Assert.assertNotNull(changePasswordPage,"user cannot directed to Change Password page");
    }

    @Test
    public void TC07() {
        System.out.println("User can create new account");
        HomePage homePage = new HomePage();
        homePage.open();
        RegisterPage Registerpage = new RegisterPage();
        Registerpage = homePage.gotoRegisterPage();
        String actualMsg = Registerpage.login(Constant.EMAIL, Constant.PASSWORD, Constant.CFpassword, Constant.PID).getWelcomeRegister();
        String expectedMsg = "Registration Confirmed! You can now log in to the site.";
        Assert.assertEquals(actualMsg, expectedMsg, "Welcome message is not displayed as expected");
    }
    @Test
    public void TC08() {
        System.out.println("User can't login with an account hasn't been activated");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage LoginPage = homePage.gotoLoginPage();
        LoginPage.login("gfdhfhf", "gfdgdfg");
        String actualErrorMsg = LoginPage.getLblLoginErrorMsg().getText();
        String expectedErrorMsg = "Invalid username or password. Please try again.";
        Assert.assertEquals(actualErrorMsg, expectedErrorMsg, "Error message is not displayed as expected");
    }
    @Test
    public void TC09(){
        System.out.println("User can't login with an account hasn't been activated");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage LoginPage = homePage.gotoLoginPage();
        LoginPage.login(Constant.USERNAME, Constant.PASSWORD);
        ChangePasswordPage  CPPage = new ChangePasswordPage();
        CPPage = homePage.gotoChangePasswordPage();
        CPPage.change("11102004Chi","20042004","20042004");
        String actualMsg = CPPage.getLblCPSuccessMsg().getText();
        String expectedMsg = "Your password has been updated";
        Assert.assertEquals(actualMsg, expectedMsg, "Welcome message is not displayed as expected");
    }
    @Test
    public void TC10(){
        System.out.println("User can't create account with 'Confirm password' is not the same with 'Password'");
        HomePage homePage = new HomePage();
        homePage.open();
        RegisterPage Registerpage = new RegisterPage();
        Registerpage = homePage.gotoRegisterPage();
        Registerpage.login("chi@gmail.com","111004","11102004","12345679");
        String actualMsg = Registerpage.getlblRegisterErrorMsg().getText();
        String expectedMsg = "There're errors in the form. Please correct the errors and try again.";
        Assert.assertEquals(actualMsg, expectedMsg, "Welcome message is not displayed as expected");

    }
    @Test
    public void TC11(){
        System.out.println("User can't create account with 'Confirm password' is not the same with 'Password'");
        HomePage homePage = new HomePage();
        homePage.open();
        RegisterPage Registerpage = new RegisterPage();
        Registerpage = homePage.gotoRegisterPage();
        Registerpage.login("chi@gmail.com","","","");
        String actualMsg = Registerpage.getlblRegisterErrorMsg().getText();
        String actualMsgpw = Registerpage.getlblRegisterErrorpwMsg().getText();
        String actualMsgpid = Registerpage.getlblRegisterErrorpidMsg().getText();

        String expectedMsg = "There're errors in the form. Please correct the errors and try again.";
        String expectedMsgpw = "Invalid password length";
        String expectedMsgpid = "Invalid ID length";
        Assert.assertEquals(actualMsg, expectedMsg, "Welcome message is not displayed as expected");
        Assert.assertEquals(actualMsgpw, expectedMsgpw, "Welcome message is not displayed as expected");
        Assert.assertEquals(actualMsgpid, expectedMsgpid, "Welcome message is not displayed as expected");
    }
    @Test
    public void TC12 (){
        System.out.println("Errors display when password reset token is blank");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage lgp = new LoginPage();
        lgp = homePage.gotoLoginPage();
        lgp.gotofwpwPage();
        lgp.Getemail("phamchi11102004@gmail.com");
        Assert.assertTrue(false,"BUG do khong gui duoc mail");
    }
    @Test
    public void TC13(){
        System.out.println("Errors display if password and confirm password don't match when resetting password");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage lgp = new LoginPage();
        lgp = homePage.gotoLoginPage();
        lgp.gotofwpwPage();
        lgp.Getemail("phamchi11102004@gmail.com");
        Assert.assertTrue(false,"BUG do khong gui duoc mail");
    }
    @Test
    public void TC14(){
        System.out.println("User can book 1 ticket at a time");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login("phamchi11102004@gmail.com", "20042004");
        BookTicketPage Btk = new BookTicketPage();
        Btk = homePage.gotoBookTicketPage();
        Random random = new Random();
        int randomDateindex = random.nextInt(28) + 3;
        Btk.book(String.valueOf(randomDateindex),"Sài Gòn","Nha Trang","Soft bed with air conditioner","1");
        String actualMsg = Btk.getlblBookSuccessMsg().getText();
        String expectedMsg = "Ticket booked successfully!";
        Assert.assertEquals(actualMsg, expectedMsg, "Welcome message is not displayed as expected");
    }


    @Test
    public void TC15(){
        System.out.println("User can open 'Book ticket' page by clicking on 'Book ticket' link in 'Train timetable' page");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login("phamchi11102004@gmail.com", "20042004");
        TimetablePage ttp = new TimetablePage();
        ttp = homePage.gotoTimetablePage();
        JavascriptExecutor js = (JavascriptExecutor) Constant.WEBDRIVER;
        js.executeScript("window.scrollBy(0,350)", "");
        ttp.gotobookticketPage();

    }

    @Test
    public void TC16() {
        System.out.println("TC16 - User can cancel a ticket");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.login("phamchi11102004@gmail.com", "20042004");
        new BookTicketPage();
        BookTicketPage Btk = homePage.gotoBookTicketPage();
        Random random = new Random();
        int randomDateindex = random.nextInt(28) + 3;
        Btk = Btk.book(String.valueOf(randomDateindex), "Sài Gòn","Nha Trang","Soft bed with air conditioner","1");
        String url = Btk.getURL();
        String id = url.split("id=")[1];
        MyTicketPage Mtp = homePage.gotoMyTicketPage();
        Mtp.CancelTicket(id);
    }
}




