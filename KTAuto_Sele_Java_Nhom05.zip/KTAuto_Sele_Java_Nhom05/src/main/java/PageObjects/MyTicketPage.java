package PageObjects;
import Common.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import javax.swing.*;

public class MyTicketPage {
    private final By _txtTicketHeader = By.xpath("//h1[@align='center']");

    public WebElement getTicketHeader() {
        return Constant.WEBDRIVER.findElement(_txtTicketHeader);
    }

    public ChangePasswordPage gotoChangePasswordPage() {
        return new ChangePasswordPage();
    }

    public AbstractButton getMyTicketPage() {
        return null;
    }
    public void CancelTicket(String id) {
        By btnCancel = By.xpath("//input[@onclick='DeleteTicket(" + id + ");']");
        Constant.WEBDRIVER.findElement(btnCancel).click();
    }

    public boolean CheckCancel(String id) {
        By btnCancel = By.xpath("//input[@onclick='DeleteTicket(" + id + ");']");

        try {
            Constant.WEBDRIVER.findElement(btnCancel);
            return false;
        } catch (NoSuchElementException var4) {
            return true;
        }
    }

}
