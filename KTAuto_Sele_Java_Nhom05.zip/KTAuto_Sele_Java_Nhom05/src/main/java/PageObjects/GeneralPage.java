package PageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Common.Utilities;
import Common.Constant;

import javax.swing.*;

public class GeneralPage {
    //Locators
    private final By tabLogin = By.xpath("//div[@id='menu']//a[@href='/Account/Login.cshtml']");
    private final By tabLogout = By.xpath("//div[@id='menu']//a[@href='/Account/Logout']");
    private final By lblWelcomeMessage = By.xpath("//div[@class='account']/strong");
    private final By tabMyTicket = By.xpath("//*[@id='menu']/ul/li[7]/a");
    private final By tabChangePassword = By.xpath("//*[@id='menu']/ul/li[8]/a");
    private final By tabBookTicket = By.xpath("//*[@id='menu']/ul/li[6]/a");
    private final By tabRegister = By.xpath("//*[@id='menu']/ul/li[7]/a");
    private final By _linkFPwPage = By.xpath("//*[@id='content']/ul/li[3]/a");
    private final By tabTimetable = By.xpath("//*[@id='menu']/ul/li[4]/a");

    //Elements
    protected WebElement getTabLogin(){
        return Constant.WEBDRIVER.findElement(tabLogin);
    }
    protected WebElement getTabLogout(){
        return Constant.WEBDRIVER.findElement(tabLogout);
    }
    protected WebElement getLblWelcomeMessage(){
        return Constant.WEBDRIVER.findElement(lblWelcomeMessage);
    }

    //Methods
    public String getWelcomeMessage()
    {
        return this.getLblWelcomeMessage().getText();

    }
    public LoginPage gotoLoginPage()
    {
        this.getTabLogin().click();
        return new LoginPage();
    }

    public MyTicketPage gotoMyTicketPage() {
        this.getMyTicket().click();
        return new MyTicketPage();
    }
    public BookTicketPage gotoBookTicketPage() {
        this.getBookTicket().click();
        return new BookTicketPage();
    }
    public ChangePasswordPage gotoChangePasswordPage() {
        this.getChangePassword().click();
        return new ChangePasswordPage();
    }
    public RegisterPage gotoRegisterPage() {
        this.getRegister().click();
        return new RegisterPage();
    }

    private WebElement getRegister() {
        return Constant.WEBDRIVER.findElement(tabRegister);
    }

    protected WebElement getMyTicket() {
        return Constant.WEBDRIVER.findElement(tabMyTicket);
    }
    protected WebElement getChangePassword() {
        return Constant.WEBDRIVER.findElement(tabChangePassword);
    }
    protected WebElement getBookTicket() {
        return Constant.WEBDRIVER.findElement(tabBookTicket);
    }
    protected WebElement getRegisterPage(){

        return Constant.WEBDRIVER.findElement(tabRegister);
    }
    protected WebElement getTabForgetPW() {
        return Constant.WEBDRIVER.findElement(_linkFPwPage);
    }
    protected WebElement getTabTimetable() {

        return Constant.WEBDRIVER.findElement(tabTimetable);
    }
    public LoginPage gotofwpwPage() {
        this.getTabForgetPW().click();
        return new LoginPage();
    }
    public TimetablePage gotoTimetablePage() {
        this.getTabTimetable().click();
        return new TimetablePage();
    }
}
