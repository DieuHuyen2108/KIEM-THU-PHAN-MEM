package PageObjects;

import Common.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class TimetablePage extends GeneralPage{
    private final By tabbookticket =By.xpath("//*[@id='content']/div/div/table/tbody/tr[19]/td[7]/a");
    public WebElement gettabbookticket(){
        return Constant.WEBDRIVER.findElement(tabbookticket);
    }
    String Url_Login_Page;
    public  String getCurrentPage(){
        Url_Login_Page = Constant.WEBDRIVER.getCurrentUrl();
        return Url_Login_Page;
    }
    public TimetablePage gotobookticketPage() {
        JavascriptExecutor js = (JavascriptExecutor) Constant.WEBDRIVER;
        js.executeScript("window.scrollBy(0,350)", "");
        this.gettabbookticket().click();
        return new TimetablePage();
    }
}