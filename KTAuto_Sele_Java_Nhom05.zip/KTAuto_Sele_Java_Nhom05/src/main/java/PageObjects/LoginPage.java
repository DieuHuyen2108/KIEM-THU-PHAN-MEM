package PageObjects;
import Common.Constant;
import Common.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import javax.swing.*;

public class LoginPage extends GeneralPage {
    //locator
    private final By _txtUsername = By.xpath("//input[@id='username']");
    private final By _txtPassword = By.xpath("//input[@id='password']");
    private final By _btnLogin = By.xpath("//input[@value='login']");
    private final By _lblLoginErrorMsg = By.xpath("//p[@class='message error LoginForm']");
    private final By _txtEmailAddress = By.xpath("//*[@id=\"email\"]");
    private final By _btnSendIn = By.xpath("//*[@id=\"content\"]/form/fieldset/p[2]/input");
    //Elements
    public WebElement getTxtUsername()
    {
        return Constant.WEBDRIVER.findElement(_txtUsername);
    }
    public WebElement getTxtPassword()
    {
        return Constant.WEBDRIVER.findElement(_txtPassword);
    }
    public WebElement getBtnLogin()
    {
        return Constant.WEBDRIVER.findElement(_btnLogin);
    }
    public WebElement getLblLoginErrorMsg()
    {
        return Constant.WEBDRIVER.findElement(_lblLoginErrorMsg);
    }
    public HomePage login(String username, String password)
    {
        //Submit login credentials
        this.getTxtUsername().sendKeys(username);
        this.getTxtPassword().sendKeys(password);

        JavascriptExecutor js = (JavascriptExecutor) Constant.WEBDRIVER;
        js.executeScript("window.scrollBy(0,350)", "");

        this.getBtnLogin().click();
        //Land on Home page
        return new HomePage();
    }
    public WebElement getTxtEmailAddress() {
        return Constant.WEBDRIVER.findElement(_txtEmailAddress);
    }
    public WebElement getBtnSendIn()
    {
        return Constant.WEBDRIVER.findElement(_btnSendIn);
    }

    public void fillLoginForm(String username, String password) {
        this.getTxtUsername().sendKeys(username);
        this.getTxtPassword().sendKeys(password);
    }

    public void clickLoginButton() {
        this.getBtnLogin().click();
    }

    public String getMessage() {
        return getLblLoginErrorMsg().getText();
    }
    public LoginPage Getemail(String sendemail){
        this.getTxtEmailAddress().sendKeys(sendemail);
        getBtnSendIn().submit();
        return new LoginPage();
    }



}