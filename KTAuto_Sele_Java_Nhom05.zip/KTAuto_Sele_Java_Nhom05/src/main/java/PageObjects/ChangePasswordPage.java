package PageObjects;
import Common.Constant;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import javax.swing.*;

public class ChangePasswordPage {
    private final By _headerChangePassword = By.xpath("//h1[@align='center']");
    private final By _txtcrPassword = By.xpath("//*[@id='currentPassword']");
    private final By _txtnewPassword = By.xpath("//*[@id='newPassword']");
    private final By _txtcfPassword = By.xpath("//*[@id='confirmPassword']");
    private final By _btnChangePassword = By.xpath("//input[@value='Change Password']");
    private final By _lblCPSuccessMsg = By.xpath("//p[@class='message success']");


    public WebElement getHeaderChangePassword() {
        return Constant.WEBDRIVER.findElement(_headerChangePassword);
    }

    public WebElement getTxtCrPassword(){
        return Constant.WEBDRIVER.findElement(_txtcrPassword);
    }

    public WebElement getTxtNewPassword(){
        return Constant.WEBDRIVER.findElement(_txtnewPassword);
    }

    public WebElement getTxtCfPassword(){
        return Constant.WEBDRIVER.findElement(_txtcfPassword);
    }

    public WebElement getBtnChangePassword() {
        return Constant.WEBDRIVER.findElement(_btnChangePassword);
    }

    public WebElement getLblCPSuccessMsg() {
        return Constant.WEBDRIVER.findElement(_lblCPSuccessMsg);
    }

    public  ChangePasswordPage change(String crpassword, String newpassword, String cfpassword) {
        this.getTxtCrPassword().sendKeys(crpassword);
        this.getTxtNewPassword().sendKeys(newpassword);
        this.getTxtCfPassword().sendKeys(cfpassword);
        getBtnChangePassword().click();
        return new ChangePasswordPage();
    }


}


