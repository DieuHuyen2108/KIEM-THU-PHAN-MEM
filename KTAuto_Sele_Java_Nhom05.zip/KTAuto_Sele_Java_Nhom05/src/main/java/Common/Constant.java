package Common;
import org.openqa.selenium.WebDriver;
public class Constant {
    public static final String EMAIL = "phachi11102004@gmail.com";
    public static final String PID = "12345678";
    public static final String RAILWAY_LOGIN_URL = "http://railwayb1.somee.com/Account/Login.cshtml?ReturnUrl=/Page/BookTicketPage.cshtml";;
    public static WebDriver WEBDRIVER;
    public static final String RAILWAY_URL="http://railwayb1.somee.com/Page/HomePage.cshtml";
    public static final String USERNAME="phamchi11102004@gmail.com";
    public static final String PASSWORD ="11102004Chi";
    public static final String CFpassword = "11102004Chi";
    public static final String CONFIRM_URL = "https://example.com/confirm"; // Thay thế URL thật nếu cần
}
