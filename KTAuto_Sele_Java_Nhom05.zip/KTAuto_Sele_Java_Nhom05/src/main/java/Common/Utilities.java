package Common;

public class Utilities {
}
